This isn't anything fancy, all I did was update the SDK to make it work in CS:GO.

I also removed everything related to loading .nav files below version 16, which is the version CS:GO is using

and I mixed Valves code with mine to make it less readable.

I'm using the american coordinate system with Y representing the height


Known problems and TODO:

Some maps don't have a .nav file, it can be generated with 'nav_save'

Figure out what the unknown part at the end of every CNavArea is



If you copy paste this please give credits.

If you spot any mistake or have a problem with my coding style please let me know.




Contact information:

XMPP: Cre3per!@system.im/linux

YouTube: https://www.youtube.com/wolwurm

UnknownCheats: http://www.unknowncheats.me/forum/members/501581.html

Steam: http://steamcommunity.com/id/dyx/

Steam: http://steamcommunity.com/id/00l/

Steam: http://steamcommunity.com/id/iqg/



Links to the SDK:

https://github.com/pmrowla/hl2sdk-csgo/blob/49e950f3eb820d88825f75e40f56b3e64790920a/game/server/nav_area.h

https://github.com/pmrowla/hl2sdk-csgo/blob/49e950f3eb820d88825f75e40f56b3e64790920a/game/server/nav_area.cpp

https://github.com/pmrowla/hl2sdk-csgo/blob/49e950f3eb820d88825f75e40f56b3e64790920a/game/server/nav_file.cpp
