class CInput {
public:
};
