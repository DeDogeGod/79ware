class C_CSGameRules
{
};
