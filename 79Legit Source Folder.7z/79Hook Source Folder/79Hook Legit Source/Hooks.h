extern void InitializeInterfaces(); /* Handles all interfaces */
extern void InitializeVMTs(); /* Handles all vmt's. */
extern void InitializeHooks(); /* Handles all hooks. */
extern void UpdateResolver();
