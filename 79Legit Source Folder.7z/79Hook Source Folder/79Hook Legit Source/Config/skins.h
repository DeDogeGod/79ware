#include "../main.h"

class Skins
{
public:
    
    int knifeT      = WEAPON_KNIFE_KARAMBIT;
    int knifeCT     = WEAPON_KNIFE_BAYONET;
    int TknifeID    = 647;  // Crimson Tsunami
    int CTknifeID   = 440;   // Icarus Fell
    int TknifeSeed  = 0;
    int CTknfieSeed = 0;
    
    int gloveT      = GLOVE_SPORTY;
    int gloveCT     = GLOVE_SPORTY;
    int TgloveID    = 10037;
    int CTgloveID   = 10037;
    
    int galil   = 661; //
    int famas   = 604; //
    int ak      = 639; //
    int a4      = 639; //
    int a1      = 440; //
    int scout   = 624; //
    int sg      = 200; //
    int aug     = 455; //
    int awp     = 279; //d
    int g3      = 409; //
    int scar    = 597; //
    
    int glock   = 586; //
    int usp     = 653; //
    int p2000   = 71; //
    int dual    = 658; //
    int p250    = 668; //
    int tec9    = 671; //
    int five7   = 44; //
    int cz      = 643; //
    int deagle  = 527; //
    int r8      = 12; //
        
    int mac10   = 433; //
    int mp9     = 549; //
    int mp7     = 627; //
    int ump     = 436; //
    int p90     = 636; //
    int bizon   = 203; //
    
    int nova    = 590; //
    int sawed   = 638; //
    int mag7    = 666; //
    int xm      = 654; //
    int m249    = 648; //
    int negev   = 483; //
    
    int galil_Seed   = 0;
    int famas_Seed   = 0;
    int ak_Seed      = 0;
    int a4_Seed      = 0;
    int a1_Seed      = 0;
    int scout_Seed   = 0;
    int sg_Seed      = 0;
    int aug_Seed     = 0;
    int awp_Seed     = 0;
    int g3_Seed      = 0;
    int scar_Seed    = 0;
    
    int glock_Seed   = 0;
    int usp_Seed     = 0;
    int p2000_Seed   = 0;
    int dual_Seed    = 0;
    int p250_Seed    = 0;
    int tec9_Seed    = 0;
    int five7_Seed   = 0;
    int cz_Seed      = 0;
    int deagle_Seed  = 0;
    int r8_Seed      = 0;
    
    int mac10_Seed   = 0;
    int mp9_Seed     = 0;
    int mp7_Seed     = 0;
    int ump_Seed     = 0;
    int p90_Seed     = 0;
    int bizon_Seed   = 0;
    
    int nova_Seed    = 0;
    int sawed_Seed   = 0;
    int mag7_Seed    = 0;
    int xm_Seed      = 0;
    int m249_Seed    = 0;
    int negev_Seed   = 0;
};

extern Skins skin;

