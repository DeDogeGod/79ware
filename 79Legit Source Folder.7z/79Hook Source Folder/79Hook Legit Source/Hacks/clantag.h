#include "../main.h"

void skeet();
void SetScrollClanTag(string Tag);

extern SendClanTagFn SetTag;
