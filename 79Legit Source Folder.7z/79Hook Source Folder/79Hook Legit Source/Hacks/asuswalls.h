#include "../main.h"

void asuswalls(ClientFrameStage_t stage);
