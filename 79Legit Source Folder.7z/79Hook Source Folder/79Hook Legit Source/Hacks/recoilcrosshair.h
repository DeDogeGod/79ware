#include "main.h"

void rCrosshair(C_BaseEntity* local);
