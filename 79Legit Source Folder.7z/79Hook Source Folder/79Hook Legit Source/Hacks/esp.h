#include "main.h"

void DrawSkeleton(C_BaseEntity* pEntity, Color color);
Color GetColorBase(Color& col);
auto DrawPlayerESP() -> void;
auto pwnmymenu() -> void;
