#include "../main.h"
#include "../pstring.h"

void MakeSpammer(float frameTime);
