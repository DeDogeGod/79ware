#include "clantag.h"

void skeet() { // Fuck Skeet
    
    if(!vars.misc.clantag)
        return;
    
    static int Tick = 0;
    Tick++;
    if (Tick > 0 && Tick < 15) {
        SetClanTag("               7", "79Hook.xyz");
    }
    else if (Tick > 30 && Tick < 45) {
        SetClanTag("              79", "79Hook.xyz");
    }
    else if (Tick > 60 && Tick < 75) {
        SetClanTag("             79H", "79Hook.xyz");
    }
    else if (Tick > 90 && Tick < 105) {
        SetClanTag("            79Ho", "79Hook.xyz");
    }
    else if (Tick > 120 && Tick < 135) {
        SetClanTag("           79Hoo", "79Hook.xyz");
    }
    else if (Tick > 150 && Tick < 165) {
        SetClanTag("         79Hook", "79Hook.xyz");
    }
    else if  (Tick > 180 && Tick < 195) {
        SetClanTag("        79Hook.x", "79Hook.xyz");
    }
    else if  (Tick > 210 && Tick < 225) {
        SetClanTag("       79Hook.xy ", "79Hook.xyz");
    }
    else if (Tick > 240 && Tick < 255) {
        SetClanTag("      79Hook.xyz  ", "79Hook.xyz");
    }
    else if (Tick > 270 && Tick < 285) {
        SetClanTag("     79Hook.xyz   ", "79Hook.xyz");
    }
    else if (Tick > 300 && Tick < 315) {
        SetClanTag("    79Hook.xyz     ", "79Hook.xyz");
    }
    else if (Tick > 330 && Tick < 345) {
        SetClanTag("   79Hook.xyz       ", "79Hook.xyz");
    }
    else if (Tick > 360 && Tick < 375) {
        SetClanTag("  79Hook.xyz      ", "79Hook.xyz");
    }
    else if (Tick > 390 && Tick < 405) {
        SetClanTag(" 79Hook.xyz       ", "79Hook.xyz");
    }
    else if (Tick > 420 && Tick < 435) {
        SetClanTag("79Hook.xyz        ", "79Hook.xyz");
    }
    else if (Tick > 450 && Tick < 465) {
        SetClanTag("9Hook.xyz         ", "79Hook.xyz");
    }
    else if (Tick > 480 && Tick < 495) {
        SetClanTag("Hook.xyz          ", "79Hook.xyz");
    }
    else if (Tick > 510 && Tick < 525) {
        SetClanTag("ook.xyz           ", "79Hook.xyz");
    }
    else if (Tick > 540 && Tick < 555) {
        SetClanTag("ok.xyz            ", "79Hook.xyz");
    }
    else if (Tick > 570 && Tick < 585) {
        SetClanTag("k.xyz             ", "79Hook.xyz");
    }
    else if (Tick > 600 && Tick < 615) {
        SetClanTag(".xyz              ", "79Hook.xyz");
    }
    else if (Tick > 630 && Tick < 645) {
        SetClanTag("xy             ", "79Hook.xyz");
    }
    else if (Tick > 660 && Tick < 675) {
        SetClanTag("                ", "79Hook.xyz");
    }
    
    if (Tick > 675) {
        Tick = 0;
    }
}

auto start = chrono::high_resolution_clock::now();
float TickCounter = 0;

void SetScrollClanTag(string Tag) {
    
    if(!vars.misc.clantag)
        return;
    
    int TagLength = Tag.length();
    string Space;
    
    for (int i = 0; i < TagLength; i++)
        Space += " ";
    
    string SpaceTag = Space + Tag + Space;
    
    if (TickCounter / 1000.0f > TagLength * 2)
        start = chrono::high_resolution_clock::now();
    
    string CurrentSubStr = SpaceTag.substr((int)(TickCounter / 1000.0f), TagLength);
    SetClanTag(CurrentSubStr.c_str(), CurrentSubStr.c_str());
    TickCounter = chrono::duration_cast<chrono::milliseconds>(chrono::high_resolution_clock::now() - start).count();
}
