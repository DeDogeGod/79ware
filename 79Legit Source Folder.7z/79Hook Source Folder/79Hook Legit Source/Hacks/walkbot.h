#include "../main.h"

void Walk( CUserCmd *cmd );
